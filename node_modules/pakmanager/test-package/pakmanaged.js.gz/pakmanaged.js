var global = Function("return this;")();
/*jshint strict:true node:true es5:true onevar:true laxcomma:true laxbreak:true eqeqeq:true immed:true latedef:true*/
(function () {
  "use strict";

  var oldRequire = global.require
    , modules = {}
    ;

  function newRequire(modulename) {
    var err
      , mod
      , metamod
      ;

    try {
      mod = oldRequire(modulename);
    } catch(e) {
      err = e;
    }

    if (mod) {
      return mod;
    }

    metamod = modules[modulename];
    
    if (metamod) {
      mod = metamod();
      return mod;
    }

    // make it possible to require 'process', etc
    mod = global[modulename];

    if (mod) {
      return mod;
    }

    throw err;
  }

  function provide(modulename, factory) {
    var modReal
      ;

    function metamod() {
      if (!modReal) {
        if (factory.__pakmanager_factory__) {
          modReal = factory();
        } else {
          modReal = factory;
        }
      }

      return modReal;
    }

    modules[modulename] = metamod;
    // somewhat of a dirty hack since I don't have a plug for loading the "main" module otherwise
    modules['pakmanager.main'] = metamod;
  }

  require = newRequire;
  global.require = newRequire;
  global.provide = provide;
}());

// pakmanager:test-package/lib/baz
(function (context) {
  function factory() {
  
  var module = { exports: {} }, exports = module.exports
    ;
  
  /*jshint strict:true node:true es5:true onevar:true laxcomma:true laxbreak:true eqeqeq:true immed:true latedef:true*/
    (function () {
      "use strict";
    
      console.log('baz');
    
      module.exports.fump = function () {
        var bar =  require('test-package/lib/bar');
      };
    }());
    
    return module.exports;
  }
  factory.__pakmanager_factory__ = true;
  provide("test-package/lib/baz", factory);
}(global));

// pakmanager:test-package/lib/bar
(function (context) {
  function factory() {
  
  var module = { exports: {} }, exports = module.exports
    ;
  
  /*jshint strict:true node:true es5:true onevar:true laxcomma:true laxbreak:true eqeqeq:true immed:true latedef:true*/
    (function () {
      "use strict";
    
      console.log('bar');
    
      module.exports.fump = function () {
        var baz =  require('test-package/lib/baz');
      };
    }());
    
    return module.exports;
  }
  factory.__pakmanager_factory__ = true;
  provide("test-package/lib/bar", factory);
}(global));

// pakmanager:test-package/lib/foo
(function (context) {
  function factory() {
  
  var module = { exports: {} }, exports = module.exports
    ;
  
  /*jshint strict:true node:true es5:true onevar:true laxcomma:true laxbreak:true eqeqeq:true immed:true latedef:true*/
    (function () {
      "use strict";
    
      console.log('foo');
    }());
    
    return module.exports;
  }
  factory.__pakmanager_factory__ = true;
  provide("test-package/lib/foo", factory);
}(global));

// pakmanager:test-package
(function (context) {
  function factory() {
  
  var module = { exports: {} }, exports = module.exports
    ;
  
  /*jshint strict:true node:true es5:true onevar:true laxcomma:true laxbreak:true eqeqeq:true immed:true latedef:true*/
    (function () {
      "use strict";
    
      var foo =  require('test-package/lib/foo')
        , bar =  require('test-package/lib/bar')
        , baz =  require('test-package/lib/baz')
        ;
    
      console.log('hello');
    }());
    
    return module.exports;
  }
  factory.__pakmanager_factory__ = true;
  provide("test-package", factory);
}(global));
require("pakmanager.main");
